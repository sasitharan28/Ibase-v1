package com.Ibase.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.Ibase.model.IbaseShop;
import com.Ibase.service.IbaseShopService;

@CrossOrigin(origins = {"http://localhost:3000"})
@RestController
@RequestMapping("/api")
public class IbaseShopController {
	
	@Autowired
	IbaseShopService IbaseShopService;
	
	@GetMapping("/shops")
	public ResponseEntity<List<IbaseShop>> getAllShops(){
		//System.out.println("hii");
		return IbaseShopService.getAllShops();
	}
	
	@GetMapping("/shops/{shopId}")
	public ResponseEntity<IbaseShop> getShopById(@PathVariable String shopId){
		return IbaseShopService.getShopById(shopId);
	}
	
	@PostMapping("/shops")
	public ResponseEntity<IbaseShop> createShop( @RequestBody IbaseShop shop){
		return IbaseShopService.createShop(shop);
	}
	
	@PutMapping("/shops/{shopId}")
	public ResponseEntity<IbaseShop> updateShop(@RequestBody IbaseShop shop , @PathVariable String shopId){
		//System.out.println("hii");
		return IbaseShopService.updateShop(shopId,shop);
	}
	
	@DeleteMapping("/shops/{shopId}")
	public ResponseEntity deleteShop(@PathVariable String shopId) {
		return IbaseShopService.deleteShopById(shopId);
	}
	
	
	
}
